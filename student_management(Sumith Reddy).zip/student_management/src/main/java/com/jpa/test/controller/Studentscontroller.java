package com.jpa.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.test.entity.Students;
import com.jpa.test.exception.ResourceNotFoundException;
import com.jpa.test.repository.StudentsRepository;


@RestController
@RequestMapping("/api/students")
public class Studentscontroller {
	@Autowired
	public StudentsRepository studentsRepository;
	
	//get all Students
	@GetMapping
	public List<Students>getAllStudents(){
		return this.studentsRepository.findAll();
	}
		//get Students by id
	@GetMapping("/{id}")
		public Students getMembersById(@PathVariable (value = "id") long studentsId) {
			return this.studentsRepository.findById(studentsId)
					.orElseThrow(()->new ResourceNotFoundException("user not found with id:" + studentsId));
	}
	//create students
	@PostMapping
	public Students createMembers(@RequestBody Students students) {
		
		return this.studentsRepository.save(students);
	}
			//update students
	@PutMapping("/{id}")
	public Students updateMembers(@RequestBody Students students,@PathVariable("id") long studentsId) {
		Students existingMembers =  this.studentsRepository.findById(studentsId)
				.orElseThrow(()->new ResourceNotFoundException("user not found with id:" + studentsId));
		existingMembers.setName(students.getName());
		existingMembers.setLastName(students.getLastName());
		existingMembers.setPhoneNo(students.getPhoneNo());
		existingMembers.setStandard(students.getStandard());
		return this.studentsRepository.save(existingMembers);
	}
	//delete Members by id
	@DeleteMapping("/{id}")
	public ResponseEntity<Students> deleteStudents(@PathVariable ("id")long studentsId){
		Students existingStudents =  this.studentsRepository.findById(studentsId)
				.orElseThrow(()->new ResourceNotFoundException("user not found with id:" + studentsId));
		this.studentsRepository.delete(existingStudents);
		return ResponseEntity.ok().build();
		
		
	}

		}
		

